import { Component, OnInit } from '@angular/core';
import { SlotService } from '../slot.service';
import { Slot } from '../slot.model';
import { Router } from '@angular/router';


@Component({
  selector: 'app-slot-list',
  templateUrl: './slot-list.component.html',
  styleUrls: ['./slot-list.component.css']
})
export class SlotListComponent implements OnInit {
  
  slots: Slot[] = [];
  displayedColumns: string[] = [
    'productName',
    'productCategory',
    'productDesc',
    'location',
    'productPrice'
  ];

  constructor(private slotService: SlotService,private router: Router) {}

  ngOnInit() {
    this.slotService.getAll().subscribe((data: Slot[]) => {
      this.slots = data;
      this.slots.forEach((slot) => {
        slot.productImgUrl = 'data:image/png;base64,'+slot.productImg;
      });
    });
  }
  arrayBufferToBase64(buffer: Uint8Array) {
    if (!buffer) {
      return ''; // Handle the case when the buffer is null or undefined
    }

    const binary = Array.from(buffer).map((byte) => String.fromCharCode(byte)).join('');
    return 'data:image/png;base64,' + btoa(binary);
  }

  viewSlots(productId: string) {
    // Navigate to the slot-details page with the product ID as a route parameter
    this.router.navigate(['/slot-details', productId]);
  }
   
startChatWithSeller(userId: string, name: string,id:string,productPrice:number) {
  this.router.navigate(['/chat'], {
    queryParams: { userId, name,id,productPrice },
  });
}
}
