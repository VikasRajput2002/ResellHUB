import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '../User.model';
import { UserService } from '../user.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent {
  constructor(private userService:UserService, private router:Router){}
  user = new User();
  confirmpassword:any;
  register()
  {
    if(this.user.password != this.confirmpassword)
    {
      alert('password does not matched !');
      return;
    }

    this.userService.addUser(this.user).subscribe(
      data=>{
        this.user = data;
        alert(`${this.user.name} registered successfully`);
        this.router.navigate(['/login']);

      },
      error=>{console.log(error);}
    )
  }

}
