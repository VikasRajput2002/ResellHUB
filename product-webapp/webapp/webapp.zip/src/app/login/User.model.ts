export class User{
    userId!:string;
    email!:string;
    name!:string;
    mobile!:string;
    gender!:string;
    password!:string;
    address!:string;
}