// booking-slot.model.ts
export interface BookingSlot {
  
    bookingDate: string; // Adjust the type if it's not a string
    startTime: string; // Adjust the type if it's not a string
    endTime: string; // Adjust the type if it's not a string
    // Add other properties as needed
  }
  
