import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ImageService {
  private profileImageUrlSubject: BehaviorSubject<string> = new BehaviorSubject<string>('');

  setProfileImageUrl(imageUrl: string): void {
    this.profileImageUrlSubject.next(imageUrl);
  }

  getProfileImageUrl(): BehaviorSubject<string> {
    return this.profileImageUrlSubject;
  }
}
