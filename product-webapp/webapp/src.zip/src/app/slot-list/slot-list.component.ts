import { Component, OnInit } from '@angular/core';
import { SlotService } from './slot.service';
import { Slot } from './slot.model';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from '../add-product/product.service';
import { Product } from '../add-product/product.model';
import { AuthService } from '../home/auth.service';


@Component({
  selector: 'app-slot-list',
  templateUrl: './slot-list.component.html',
  styleUrls: ['./slot-list.component.css']
})
export class SlotListComponent implements OnInit {

  selectedProductId: string | null = null;
  similarProduct: Product[] = [];
  slots: Slot[] = [];
  displayedColumns: string[] = [
    'id',
    'productName',
    'productCategory',
    'productDesc',
    'location',
    'productPrice',
    'userId',
    'name'
  ];

  convertSimilarProductImages(similarProducts: Product[]) {
    similarProducts.forEach((product) => {
      product.productImg = 'data:image/png;base64,' + product.productImg;
    });
  }

  constructor(private slotService: SlotService,
    private router: Router,
    private productService: ProductService,
    private route: ActivatedRoute,
    ) {}

ngOnInit() {
  this.route.params.subscribe((params) => {
    this.selectedProductId = params['id'];

    // Fetch slot data and filter based on selectedProductId
    this.slotService.getAll().subscribe((data: Slot[]) => {
      this.slots = data.filter((slot) => slot.id === this.selectedProductId);
      console.log('Slots:', this.slots);

    this.slots.forEach((slot) => {
      slot.productImgUrl = 'data:image/png;base64,' + slot.productImg;
    });
  });
});



  // Fetch similar products data
  this.route.queryParams.subscribe((queryParams) => {
    const productCategory = queryParams['productCategory'];

    if (productCategory) {
      this.productService.getProductsByCategory(productCategory).subscribe((similarProducts: Product[]) => {
        const selectedProductId = this.route.snapshot.params['id']; // Assuming you have the selected product's ID in the route parameters

        // Use the convertSimilarProductImages method to convert similar product images
        this.convertSimilarProductImages(similarProducts);

        // Filter out the selected product
        this.similarProduct = similarProducts.filter((product) => product.id !== selectedProductId);
      });
    }
  });
}

    
    arrayBufferToBase64(buffer: Uint8Array) {
      if (!buffer) {
        return '';
      }
    
      const binary = Array.from(buffer).map((byte) => String.fromCharCode(byte)).join('');
      return 'data:image/png;base64,' + btoa(binary);
    }
    

  viewSlots(productId: string) {
    
    this.router.navigate(['/slot-details', productId]);
  }

 
  startChatWithSeller(userId: string, name: string, id: string, productPrice: number) {
    
      this.router.navigate(['/chat'], {
        queryParams: { userId, name, id, productPrice },
      });
    }

    navigateToProductDetails(productId: string,productCategory: string) {

      this.router.navigate(['product',productId],{
        queryParams: { productCategory},

      });
    }
  }
  

