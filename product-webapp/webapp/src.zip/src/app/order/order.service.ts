import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http:HttpClient) { }
  public getOrders(userId:String){
    return this.http.get(`http://localhost:8065/orders/${userId}`);

  }
  public getOrderById(orderId:String){
    return this.http.get(`http://localhost:8065/orders/order/${orderId}`);

  }
}
